from django.contrib.auth.forms import UserCreationForm

class SignUpForm(UserCreationForm):
    pass